<?php

namespace App\Http\Requests;

use App\Rules\TimeValidation;
use Illuminate\Foundation\Http\FormRequest;

class BookingCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "customer_id" => "required|numeric|exists:users,id",
            "garage_id" => "required|numeric|exists:garages,id",
            // "customer_id",
            "automobile_make_id" => "required|numeric",
            "automobile_model_id" =>"required|numeric",
            "car_registration_no" => "required|string",
            "car_registration_year" => "nullable|date",
            "additional_information" => "nullable|string",
            // "status",
            "job_start_date" => "required|date",
            "job_start_time" => ['nullable','date_format:H:i', new TimeValidation
        ],
            // "job_end_date" => "required|date",
            "coupon_code" => "nullable|string",

    'booking_sub_service_ids' => 'nullable|array',
    'booking_sub_service_ids.*' => 'nullable|numeric',

    'booking_garage_package_ids' => 'nullable|array',
    'booking_garage_package_ids.*' => 'nullable|numeric',

    "fuel" => "nullable|string",
    "transmission" => "nullable|string",


    "job_start_date" => "required|date",
    "job_start_time" => ['required','date_format:H:i', new TimeValidation
],
    "job_end_time" => ['required','date_format:H:i', new TimeValidation
],

"price" => "required|numeric",
"discount_type" => "nullable|string|in:fixed,percentage",
"discount_amount" => "required_if:discount_type,!=,null|numeric|min:0",


        ];
    }
}
