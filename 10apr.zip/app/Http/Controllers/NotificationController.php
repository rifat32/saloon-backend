<?php

namespace App\Http\Controllers;

use App\Http\Utils\ErrorUtil;
use App\Models\Notification;
use Exception;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    use ErrorUtil;

    /**
     *
     * @OA\Get(
     *      path="/v1.0/notifications/{perPage}",
     *      operationId="getNotifications",
     *      tags={"basics_management"},
     *       security={
     *           {"bearerAuth": {}}
     *       },
     *              @OA\Parameter(
     *         name="perPage",
     *         in="path",
     *         description="perPage",
     *         required=true,
     *  example="6"
     *      ),

     *      summary="This method is to get notification",
     *      description="This method is to get notification",
     *

     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\JsonContent(),
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     * @OA\JsonContent(),
     *      ),
     *        @OA\Response(
     *          response=422,
     *          description="Unprocesseble Content",
     *    @OA\JsonContent(),
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden",
     *   @OA\JsonContent()
     * ),
     *  * @OA\Response(
     *      response=400,
     *      description="Bad Request",
     *   *@OA\JsonContent()
     *   ),
     * @OA\Response(
     *      response=404,
     *      description="not found",
     *   *@OA\JsonContent()
     *   )
     *      )
     *     )
     */

    public function getNotifications($perPage, Request $request)
    {
        try {


            $notificationsQuery = Notification::where([
                "receiver_id" => $request->user()->id
            ]);



            $notifications = $notificationsQuery->orderByDesc("id")->paginate($perPage);

            $total_data = count($notifications["data"]);
            for ($i = 0; $i < $total_data; $i++) {

                $notifications["data"][$i]["template_string"] = json_decode($notifications["data"][$i]->template->template);


                if (!empty($notifications["data"][$i]->customer_id)) {
                    $notifications["data"][$i]["template_string"] =  str_replace(
                        "[customer_name]",

                        ($notifications["data"][$i]->customer->first_Name . " " . $notifications["data"][$i]->customer->last_Name),

                        $notifications["data"][$i]["template_string"]
                    );
                }

                if (!empty($notifications["data"][$i]->garage_id)) {
                    $notifications["data"][$i]["template_string"] =  str_replace(
                        "[garage_owner_name]",

                        ($notifications["data"][$i]->garage->owner->first_Name . " " . $notifications["data"][$i]->garage->owner->last_Name),

                        $notifications["data"][$i]["template_string"]
                    );

                    $notifications["data"][$i]["template_string"] =  str_replace(
                        "[garage_name]",

                        ($notifications["data"][$i]->garage->name),

                        $notifications["data"][$i]["template_string"]
                    );
                }


                $notifications["data"][$i]["link"] = json_decode($notifications["data"][$i]->template->link);



                $notifications["data"][$i]["link"] =  str_replace(
                    "[customer_id]",
                    $notifications["data"][$i]->customer_id,
                    $notifications["data"][$i]["link"]
                );

                $notifications["data"][$i]["link"] =  str_replace(
                    "[pre_booking_id]",
                    $notifications["data"][$i]->pre_booking_id,
                    $notifications["data"][$i]["link"]
                );

                $notifications["data"][$i]["link"] =  str_replace(
                    "[garage_id]",
                    $notifications["data"][$i]->garage_id,
                    $notifications["data"][$i]["link"]
                );
            }


            return response()->json($notifications, 200);
        } catch (Exception $e) {

            return $this->sendError($e, 500);
        }
    }
}
